import { initializeApp } from 'firebase/app';
import { 
  getFirestore, 
  doc, 
  getDocFromServer, 
  collection, 
  getDocs, 
  setDoc, 
  updateDoc, 
  deleteDoc, 
  onSnapshot, 
  query, 
  orderBy,
  Unsubscribe
} from 'firebase/firestore';
import { 
  getAuth, 
  GoogleAuthProvider, 
  signInWithPopup, 
  signInWithEmailAndPassword,
  sendPasswordResetEmail,
  signOut, 
  onAuthStateChanged,
  User 
} from 'firebase/auth';
import { 
  getStorage, 
  ref as storageRef, 
  uploadBytes, 
  getDownloadURL 
} from 'firebase/storage';
import firebaseConfig from '../../firebase-applet-config.json';
import { Order, Service, SiteBrandingConfig, BannerConfig, PaymentConfig, SetupTutorialConfig } from '../types';

// 1. Initialize Firebase App
const app = initializeApp(firebaseConfig);

// 2. Initialize Firestore with explicit databaseId (MANDATORY)
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);

// 3. Initialize Auth
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();

// 4. Initialize Firebase Storage
export const storage = getStorage(app);

// 4. Firestore Error Handling Protocol
export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// 5. Test connection on boot
export async function testConnection(): Promise<boolean> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    return true;
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn("Firebase client is currently offline. Checking network...");
    }
    return false;
  }
}

// Compress image via HTML5 Canvas into ultra-lightweight WebP / JPEG (30-60KB)
export async function compressImageToDataUrl(file: File, maxWidth: number = 1000, quality: number = 0.82): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        let width = img.width;
        let height = img.height;
        if (width > maxWidth) {
          height = Math.round((height * maxWidth) / width);
          width = maxWidth;
        }
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(e.target?.result as string);
          return;
        }
        ctx.drawImage(img, 0, 0, width, height);
        try {
          const webpData = canvas.toDataURL('image/webp', quality);
          if (webpData && webpData.startsWith('data:image/webp') && webpData.length > 100) {
            resolve(webpData);
            return;
          }
        } catch (_) {}
        resolve(canvas.toDataURL('image/jpeg', quality));
      };
      img.onerror = () => reject(new Error('ইমেজ ফাইল লোড করা যায়নি'));
      img.src = e.target?.result as string;
    };
    reader.onerror = () => reject(new Error('ফাইল পড়তে সমস্যা হয়েছে'));
    reader.readAsDataURL(file);
  });
}

// Timeout helper to avoid infinite hanging
function withTimeout<T>(promise: Promise<T>, ms: number = 3000): Promise<T> {
  return Promise.race([
    promise,
    new Promise<T>((_, reject) => setTimeout(() => reject(new Error('Upload timeout')), ms))
  ]);
}

function sanitizeForFirestore<T>(data: T): any {
  if (data === null || data === undefined) return null;
  if (typeof data !== 'object') return data;
  if (Array.isArray(data)) {
    return data.map(sanitizeForFirestore);
  }
  const clean: Record<string, any> = {};
  for (const [key, value] of Object.entries(data as Record<string, any>)) {
    if (value !== undefined) {
      clean[key] = sanitizeForFirestore(value);
    }
  }
  return clean;
}

// 6. Realtime Subscriptions & CRUD Helpers
export const firebaseService = {
  // Listen to orders collection in real-time across devices
  subscribeOrders(onUpdate: (orders: Order[]) => void, onError?: (err: any) => void): Unsubscribe {
    return onSnapshot(
      collection(db, 'orders'), 
      (snapshot) => {
        const orders: Order[] = [];
        snapshot.forEach((docSnap) => {
          orders.push(docSnap.data() as Order);
        });
        orders.sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime());
        onUpdate(orders);
      },
      (error) => {
        console.warn('Orders subscription error:', error);
        if (onError) onError(error);
      }
    );
  },

  // Save or update an order in Firestore
  async saveOrder(order: Order): Promise<void> {
    const path = `orders/${order.id}`;
    const cleanPayload = sanitizeForFirestore(order);
    try {
      await setDoc(doc(db, 'orders', order.id), cleanPayload);
    } catch (error) {
      console.warn('saveOrder to cloud warning:', error);
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  },

  // Update order status or fields
  async updateOrder(orderId: string, updates: Partial<Order>): Promise<void> {
    const path = `orders/${orderId}`;
    const cleanPayload = sanitizeForFirestore({
      ...updates,
      updatedAt: Date.now()
    });
    try {
      await updateDoc(doc(db, 'orders', orderId), cleanPayload);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  },

  // Delete an order
  async deleteOrder(orderId: string): Promise<void> {
    const path = `orders/${orderId}`;
    try {
      await deleteDoc(doc(db, 'orders', orderId));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, path);
    }
  },

  // Listen to Services in real-time
  subscribeServices(onUpdate: (services: Service[]) => void): Unsubscribe {
    return onSnapshot(
      collection(db, 'services'),
      (snapshot) => {
        const services: Service[] = [];
        snapshot.forEach((docSnap) => {
          services.push(docSnap.data() as Service);
        });
        onUpdate(services);
      },
      (error) => {
        console.warn('Services subscription notice:', error);
      }
    );
  },

  // Save Service package
  async saveService(service: Service): Promise<void> {
    const path = `services/${service.id}`;
    const cleanPayload = sanitizeForFirestore(service);
    try {
      await setDoc(doc(db, 'services', service.id), cleanPayload);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  },

  // Delete Service package
  async deleteService(serviceId: string): Promise<void> {
    const path = `services/${serviceId}`;
    try {
      await deleteDoc(doc(db, 'services', serviceId));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, path);
    }
  },

  // Listen to Branding
  subscribeBranding(onUpdate: (branding: SiteBrandingConfig) => void): Unsubscribe {
    return onSnapshot(
      doc(db, 'settings', 'branding'),
      (snapshot) => {
        if (snapshot.exists()) {
          onUpdate(snapshot.data() as SiteBrandingConfig);
        }
      },
      (error) => {
        console.warn('Branding subscription notice:', error);
      }
    );
  },

  async saveBranding(branding: SiteBrandingConfig): Promise<void> {
    const path = 'settings/branding';
    try {
      await setDoc(doc(db, 'settings', 'branding'), branding);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  },

  // Listen to Payment Configuration
  subscribePaymentConfig(onUpdate: (config: PaymentConfig) => void): Unsubscribe {
    return onSnapshot(
      doc(db, 'settings', 'payment'),
      (snapshot) => {
        if (snapshot.exists()) {
          onUpdate(snapshot.data() as PaymentConfig);
        }
      },
      (error) => {
        console.warn('Payment subscription notice:', error);
      }
    );
  },

  async savePaymentConfig(config: PaymentConfig): Promise<void> {
    const path = 'settings/payment';
    try {
      await setDoc(doc(db, 'settings', 'payment'), config);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  },

  // Listen to Top Banner
  subscribeBanner(onUpdate: (banner: BannerConfig) => void): Unsubscribe {
    return onSnapshot(
      doc(db, 'settings', 'banner'),
      (snapshot) => {
        if (snapshot.exists()) {
          onUpdate(snapshot.data() as BannerConfig);
        }
      },
      (error) => {
        console.warn('Banner subscription notice:', error);
      }
    );
  },

  async saveBanner(banner: BannerConfig): Promise<void> {
    const path = 'settings/banner';
    try {
      await setDoc(doc(db, 'settings', 'banner'), banner);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  },

  // Google Login for Admin (Firebase Auth)
  async loginWithGoogle(): Promise<User> {
    const result = await signInWithPopup(auth, googleProvider);
    return result.user;
  },

  // Email & Password Login for Admin (Firebase Auth)
  async loginWithEmail(email: string, pass: string): Promise<User> {
    const result = await signInWithEmailAndPassword(auth, email, pass);
    return result.user;
  },

  // Secure Password Reset Email (Firebase Auth)
  async sendPasswordReset(email: string): Promise<void> {
    await sendPasswordResetEmail(auth, email);
  },

  // Auth State Listener
  subscribeAuthState(callback: (user: User | null) => void): Unsubscribe {
    return onAuthStateChanged(auth, callback);
  },

  // Fast & 100% Reliable Image Upload (Zero-Hanging, Instant Compressed Data URL)
  async uploadImage(file: File, folder: string = 'images'): Promise<string> {
    // 1. Immediately create a ultra-lightweight, crisp compressed version (~30KB)
    let fallbackDataUrl = '';
    try {
      fallbackDataUrl = await compressImageToDataUrl(file, 640, 0.78);
    } catch (_) {
      // Continue if canvas compression fails
    }

    // 2. Try Firebase Storage with 1.2s strict timeout (never hangs)
    try {
      const extension = file.name.split('.').pop() || 'jpg';
      const cleanFileName = `${folder}/${Date.now()}_${Math.random().toString(36).substring(2, 7)}.${extension}`;
      const fileRef = storageRef(storage, cleanFileName);
      const snapshot = await withTimeout(uploadBytes(fileRef, file, {
        contentType: file.type || 'image/jpeg'
      }), 1200);
      const downloadUrl = await withTimeout(getDownloadURL(snapshot.ref), 1200);
      if (downloadUrl && downloadUrl.startsWith('http')) {
        return downloadUrl;
      }
    } catch (storageErr) {
      console.warn('Firebase Storage skipped or timed out, using instant compressed image:', storageErr);
    }

    // 3. Instant 100% Guaranteed Image (always works on GitHub Pages & mobile)
    if (fallbackDataUrl) {
      return fallbackDataUrl;
    }

    // Fallback: direct DataURL read
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => resolve(e.target?.result as string);
      reader.onerror = () => reject(new Error('ছবি লোড করা সম্ভব হয়নি।'));
      reader.readAsDataURL(file);
    });
  },

  async logout(): Promise<void> {
    await signOut(auth);
  }
};

// Initial connection test
testConnection();
